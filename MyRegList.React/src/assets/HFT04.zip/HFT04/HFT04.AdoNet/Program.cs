﻿using System;
using System.Data.SqlClient;

namespace HFT04.AdoNet
{
    internal class Program
    {

        static void Insert(int id, string title, SqlConnection conn)
        {
            SqlCommand cmd = new SqlCommand($"insert into MOVIES (MovieId,Title,DirectorId) values ({id},'{title}',1)", conn);
            cmd.ExecuteNonQuery();
        }

        static void Main(string[] args)
        {
            string connStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Andras\source\repos\HFT04\HFT04.AdoNet\marvel.mdf;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            //Insert(28, "Dr. Strange 2", conn);
            //Insert(29, "Thor 3", conn);


            SqlCommand cmd = new SqlCommand("select * from MOVIES", conn);
            SqlDataReader reader = cmd.ExecuteReader();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (reader.GetName(i).Length > 7)
                {
                    Console.Write(reader.GetName(i).Substring(0, 7) + "\t");
                }
                else
                {
                    Console.Write(reader.GetName(i) + "\t");
                }
            }
            Console.WriteLine();
            while (reader.Read())
            {
                //Console.WriteLine(reader["Title"].ToString());
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    if (reader.GetValue(i).ToString().Length > 7)
                    {
                        Console.Write(reader.GetValue(i).ToString().Substring(0, 7) + "\t");
                    }
                    else
                    {
                        Console.Write(reader.GetValue(i).ToString() + "\t");
                    }
                    
                }
                Console.WriteLine();
            }
            reader.Close();
        }
    }
}

﻿using HFT04B.CodeFirst.Data;
using System;
using System.Linq;

namespace HFT04B.CodeFirst
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MarvelDbContext ctx = new MarvelDbContext();

            //ctx.Movies.ToList()
            //    .ForEach(t => Console.WriteLine(t.Title));

            //foreach (var item in ctx.Movies)
            //{
            //    Console.WriteLine(item.Title);
            //    foreach (var role in item.Roles)
            //    {
            //        Console.WriteLine("\t" + role.RoleName + ": " + role.Actor.ActorName);
            //    }
            //}

            //Hány filmben szerepel Robert Downey Jr.?
            int count = ctx.Actors
                .FirstOrDefault(t => t.ActorName == "Robert Downey Jr.")
                .Movies.Count;
            ;


            //Melyik a legtöbb szereplőt felsorakoztató film?
            var top = (from m in ctx.Movies
                       orderby m.Roles.Count descending
                       select m.Title).First();


            //Írjuk ki Paul Rudd szerepeit és filmjeit!
            foreach (var item in ctx.Actors.FirstOrDefault(t => t.ActorName == "Paul Rudd").Roles)
            {
                Console.WriteLine(item.RoleName + " (" + item.Movie.Title + ")");
            }



            //Évente milyen átlagértékelésű filmek születtek ?
            var avg = from m in ctx.Movies
                      group m by m.Release.Year into g
                      select new
                      {
                          Year = g.Key,
                          AvgRate = g.Average(t => t.Rating)
                      };
            ;

        }
    }
}

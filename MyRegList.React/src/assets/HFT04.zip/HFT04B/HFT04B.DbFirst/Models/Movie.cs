﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HFT04B.DbFirst.Models
{
    public partial class Movie
    {
        public decimal MovieId { get; set; }
        public string Title { get; set; }
        public double? Income { get; set; }
        public decimal DirectorId { get; set; }
        public DateTime? Release { get; set; }
        public double? Rating { get; set; }

        public virtual Director Director { get; set; }
    }
}

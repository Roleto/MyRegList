﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HFT04B.DbFirst.Models
{
    public partial class Director
    {
        public Director()
        {
            Movies = new HashSet<Movie>();
        }

        public decimal DirectorId { get; set; }
        public string DirectorName { get; set; }

        public virtual ICollection<Movie> Movies { get; set; }
    }
}

﻿using HFT04B.DbFirst.Models;
using System;
using System.Linq;

namespace HFT04B.DbFirst
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MarvelDbContext ctx = new MarvelDbContext();

            //ctx.Movies.ToList()
            //    .ForEach(t => Console.WriteLine(t.Title));

            var asd = ctx.Movies.ToArray();
            
            
            foreach (var item in ctx.Movies)
            {
                Console.WriteLine(item.Director.DirectorName + ": " + item.Title);
            }

        }
    }
}
